﻿define("epi-ecf-ui/store/CompositeKey", [
    "dojo/_base/lang",
    "dojo/when"
    ],
function (lang, when) {

    // module:
    //		epi-ecf-ui/store/CompositeKey

    var CompositeKey = function (masterStore, keys, getClones) {
        return lang.delegate(masterStore, 
            {
                keys: keys,
                getClones: getClones,
                removeReAdd: function(object, directives) {
                    var newObj = lang.clone(object),
                        promise = this.remove(object[this.idProperty]);
                    delete newObj[this.idProperty];
                    return when(promise, function() {  // Wait for remove to finish before adding
                        return masterStore.add(newObj, directives);
                    });
                },
                put: function(object, directives) {
                    var oldObj = this.get(object[this.idProperty]);
                    if(oldObj && this.keys) {
                        for(var i=0, j=this.keys.length; i<j ; i+=1) {
                            if(oldObj[keys[i]] !== object[keys[i]]) {
                                return this.removeReAdd(object, directives);
                            }
                        }
                    }
                    return masterStore.put.apply(masterStore, arguments);
                },
                get: function(id) {
                    return getClones ? lang.clone(masterStore.get.apply(masterStore, arguments)) : masterStore.get.apply(masterStore, arguments);
                }
        });
    };

    return CompositeKey;
});
