require({cache:{
'url:epi-ecf-ui/widget/templates/PricingOverview.html':"﻿<div class=\"epi-listingOverview\">\r\n    <div data-dojo-attach-point=\"header\">\r\n        <div data-dojo-type=\"epi-cms/contentediting/NotificationBar\" data-dojo-attach-point=\"notificationBar\"></div>\r\n        <div class=\"epi-view-container\">\r\n            <h1 data-dojo-attach-point=\"heading\" class=\"dijitInline\">${resources.heading}</h1>\r\n            <div data-dojo-attach-point='filterNode' class=\"epi-filterHolder\">\r\n                <div class=\"epi-filterHolderLeading\">\r\n                    <button class=\"epi-mediumButton\"\r\n                            data-dojo-attach-event='onClick: _onShowNewItem'\r\n                            data-dojo-attach-point=\"addNewItem\"\r\n                            data-dojo-type=\"dijit/form/Button\"\r\n                            data-dojo-props=\"label: '${resources.buttons.addprice}', title:'${resources.buttons.addprice}', iconClass:'epi-iconPlus'\"></button>\r\n                </div>\r\n                <div class=\"epi-filterHolderCenter clearfix\">\r\n                    <label for=\"customergroup\">${resources.selectors.customergroup}</label>\r\n                    <select name=\"customergroup\"\r\n                            data-dojo-type=\"dijit/form/Select\"\r\n                            data-dojo-attach-point=\"customerGroupSelector\"\r\n                            data-dojo-attach-event='onChange: _onCustomerGroupChanged'></select>\r\n                    <label for=\"markets\">${resources.selectors.market}</label>\r\n                    <select name=\"markets\"\r\n                            data-dojo-type=\"epi-ecf-ui/widget/MarketSelector\"\r\n                            data-dojo-attach-point=\"marketSelector\"\r\n                            data-dojo-attach-event='onChange: _onMarketChanged'></select>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div data-dojo-attach-point='listNode'></div>\r\n    <div data-dojo-attach-point='addPriceNode' class=\"dijitContentPane\">\r\n        <div data-dojo-attach-point='newItemFormNode'></div>\r\n        <div class=\"epi-floater--right\">\r\n            <button class=\"epi-mediumButton Salt\"\r\n                    data-dojo-attach-event='onClick: _onAddNewPrice'\r\n                    data-dojo-type=\"dijit/form/Button\"\r\n                    data-dojo-props=\"label: '${sharedResources.action.save}', title:'${sharedResources.action.save}'\"></button>\r\n            <button class=\"epi-mediumButton\"\r\n                    data-dojo-attach-event='onClick: _onCancelNewItem'\r\n                    data-dojo-type=\"dijit/form/Button\"\r\n                    data-dojo-props=\"label: '${sharedResources.action.cancel}', title:'${sharedResources.action.cancel}'\"></button>\r\n        </div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/PricingOverview", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/dom",
    "dojo/dom-construct",
    "dojo/dom-geometry",
    "dojo/dom-style",
// dijit
    "dijit/form/Select",
// dojox
    "dojox/html/entities",
// EPi CMS
    "epi-cms/contentediting/NotificationBar", // used in template
// commerce
    "../contentediting/editors/PricingOverviewEditor",
    "./_OverviewBase",
    "./MarketSelector",
    "./NewPrice",
    "./viewmodel/PricingOverviewModel",
// Resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview",
    "epi/i18n!epi/cms/nls/commerce.widget.market",
    "epi/i18n!epi/cms/nls/commerce.widget.customergroup",
    "epi/i18n!epi/nls/episerver.shared",
    "dojo/text!./templates/PricingOverview.html"
], function (
// dojo
    declare,
    array,
    dom,
    domConstruct,
    domGeo,
    domStyle,
// dijit
    Select,
// dojox
    entities,
// EPi CMS
    NotificationBar,
// commerce
    PricingOverviewEditor,
    _OverviewBase,
    MarketSelector,
    NewPrice,
    PricingOverviewModel,
// Resources
    resources,
    resDefaultMarket,
    resDefaultCustomerGroup,
    sharedResources,
    template
) {

    return declare([_OverviewBase], {
        // summary:
        //    Represents the widget to preview price for entries.
        // tags:
        //    public
        resources: resources,

        sharedResources: sharedResources,

        templateString: template,

        modelClassName: PricingOverviewModel,

        defaultCGItem: { id: "ALL", name: resDefaultCustomerGroup.defaultitem },

        metadata: null,

        listType: PricingOverviewEditor,

        metadataTypeName: "EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.PriceModel",

        _backToPreviousViewNotification: null,

        newItemWidgetType: NewPrice,

        // Map property name in view model to a list of properties in this widget
        modelBindingMap: {
            "markets": ["markets"],
            "customerGroups": ["customerGroups"]
        },

        postCreate: function () {
            this.inherited(arguments);
            this.model.populateData(); // load market list and customer groups.
        },

        layout: function () {
            // summary:
            //      Layout the pricing overview editor.
            // tags:
            //      protected

            this.inherited(arguments);

            var headerSize = domGeo.getMarginBox(this.header);
            var height = this._contentBox.h - headerSize.h,
                width = this._contentBox.w;

            domStyle.set(this.addPriceNode, "width", width + "px");
            domStyle.set(this.addPriceNode, "height", height + "px");
        },

        _setCustomerGroupsAttr: function (customerGroupList) {
            // summary:
            //      Sets customer group list. Let's bind this list to customer groups selector.
            // tags:
            //      private

            // Turn off change notifications while we make all these changes
            this.customerGroupSelector._onChangeActive = false;
            this.customerGroupSelector.removeOption(this.customerGroupSelector.options);

            if (customerGroupList) {
                customerGroupList.unshift(this.defaultCGItem);

                array.forEach(customerGroupList, function (customerGroup) {
                    this.customerGroupSelector.addOption({ label: entities.encode(customerGroup.name), value: entities.encode(customerGroup.id) });
                }, this);
            }

            // Turn on change notifications when we made all these changes
            this.customerGroupSelector._onChangeActive = true;
        },

        _onMarketChanged: function () {
            // summary:
            //      Filter the price list by selected market.
            var val = this.marketSelector.value;

            // Show market column when market seletor is ALL, otherwise hide it.
            if (this.list.grid) {
                if (val === "ALL") {
                    this.list.grid.styleColumn("marketId", "display: table-cell;");
                } else {
                    this.list.grid.styleColumn("marketId", "display: none;");
                }
            }

            this.list.set("marketId", val);
        },

        _onAddNewPrice: function(){
            if (this.newItemWidget.isValid()) {
                var newPrice = this.newItemWidget.get("value");
                newPrice.contentLink = this.model.content.contentLink;
                this.list.addPrice(newPrice);
                this._showNewItemView(false);
            }
        },

        _showNewItemView: function(show){
            this.heading.innerHTML = show ? this.resources.buttons.addprice : this.resources.heading;
            domStyle.set(this.addPriceNode, "display", show ? "" : "none");
            domStyle.set(this.listNode, "display", show ? "none" : "");
            domStyle.set(this.filterNode, "display", show ? "none" : "");
            if (this.newItemWidget) {
                this.newItemWidget.destroy();
                this.newItemWidget = null;
            }
            if (show){
                this._createNewItemWidget();
                this._showNewItemNotification();
            } else {
                this._backToPreviousViewNotification.showNotification();
            }
        },

        _onCustomerGroupChanged: function (){
            // summary:
            //      Filter the price list by selected customer group.
            var val = this.customerGroupSelector.value;

            // Show price type & price code column when customer group seletor is ALL, otherwise hide them.
            if (val === "ALL") {
                this.list.grid.styleColumn("priceCode", "display: table-cell;");
                this.list.grid.styleColumn("priceType", "display: table-cell;");
            } else {
                this.list.grid.styleColumn("priceCode", "display: none;");
                this.list.grid.styleColumn("priceType", "display: none;");
            }

            this.list.set("priceCode", val);
        }
    });
});
