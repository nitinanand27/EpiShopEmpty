﻿define("epi-ecf-ui/widget/viewmodel/CatalogTreeStoreModel", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/when",
    "dojo/topic",
// epi
    "epi/dependency",
    "epi/routes",
    "epi/string",
    "epi/shell/XhrWrapper",
    "epi/shell/widget/dialog/Alert",
    "epi/shell/widget/dialog/Dialog",
    "epi/shell/TypeDescriptorManager",
    "epi-cms/core/ContentReference",
    "epi-cms/widget/ContentForestStoreModel",

// epi-ecf-ui
    "../../contentediting/ModelSupport",
    "../CatalogPasteItemDialog",
    // resources
    "epi/i18n!epi/nls/commerce.components.catalogtree"
],

function (
// dojo
    array,
    declare,
    lang,
    Deferred,
    promiseAll,
    when,
    topic,
// epi
    dependency,
    routes,
    epiString,
    XhrWrapper,
    Alert,
    Dialog,
    TypeDescriptorManager,
    ContentReference,
    ContentForestStoreModel,

// epi-ecf-ui
    ModelSupport,
    CatalogPasteItemDialog,
    resources
) {
    // module:
    //      epi-ecf-ui.widget.viewmodel.CatalogTreeStoreModel

    return declare([ContentForestStoreModel], {
        // summary:
        //      Catalogs tree store model, which support listing catalog content with market filter.
        // tags:
        //      public

        relationStore: null,

        xhrHandler: null,

        // flag to indicate whether the duplicate/move/link action is performed by DnD action from Catalog list.
        _dropFromCatalogList: false,

        typeDescriptorManager: TypeDescriptorManager,

        constructor: function(){
            this.relationStore = this.relationStore || dependency.resolve("epi.storeregistry").get("epi.commerce.relation");
            this.contentTypeStore = this.contentTypeStore  || dependency.resolve("epi.storeregistry").get("epi.cms.contenttype");
            this._handles.push(topic.subscribe("relationChanged", lang.hitch(this, this._relationChanged)));
            if (!this.xhrHandler) {
                this.xhrHandler = new XhrWrapper();
            }
        },

        _relationChanged: function(addedItem){
            this._childrenChanged(addedItem.target);
        },

        newItems: function(items, newParentItem) {
            this._selectAction(items, newParentItem);
        },

        newItem: function(item, newParentItem, actionType){
            this._performAction(item, newParentItem, actionType);
        },

        pasteItems: function(items, newParentItem) {
            this._selectAction(items, newParentItem);
        },

        pasteItem: function (childItem, oldParentItem, newParentItem, actionType) {
            if (typeof actionType === 'string') {
                if (!childItem || !newParentItem) { return; }

                switch (actionType) {
                    case 'link':
                        return this._addRelation(childItem, newParentItem);
                    case 'move':
                        if (ContentReference.compareIgnoreVersion(childItem.parentLink, oldParentItem.contentLink)) {
                            var promise = this.inherited(arguments, [childItem, oldParentItem, newParentItem, false]);
                            // when moving process is completed, let's broadcast the catalogItemMoved event, so the list can clear selection and clipboard.
                            when(promise, function () {
                                topic.publish("catalogItemMoved", { childItem: childItem, oldParentItem: oldParentItem, newParentItem: newParentItem });
                            });
                            return promise;
                        } else {
                            return this._replaceRelation(childItem, oldParentItem, newParentItem);
                        }
                        break; // JsHint requires this
                    case 'duplicate':
                        return this.inherited(arguments, [childItem, oldParentItem, newParentItem, true]);
                    default:
                        break;
                }
            }
        },

        _selectAction: function(items, newParentItem) {
            var checkItems = function(items, availableContentTypeIds) {
                return array.every(items, function(item) {
                    if(!item.dndData || !item.dndData.data) {
                        return false;
                    }
                    return availableContentTypeIds.indexOf(item.dndData.data.contentTypeID) > -1;
                });
            };

            return when(this._isContentTypeAllowed(items, newParentItem, checkItems), lang.hitch(this, function(isContentTypesAllowed){
                if(!isContentTypesAllowed) {
                    this._showContentTypeAlert();
                    return false;
                }
                var isLinkSupported = this._isLinkSupported(newParentItem.typeIdentifier);
                return when(this._newItemConfirmation(false, !isLinkSupported), lang.hitch(this, function (actionType) {
                    this._dropFromCatalogList = true;
                    var deferreds = array.map(items, function (item) {
                        return this._performAction(item, newParentItem, actionType);
                    }, this);
                    var dfList = promiseAll(deferreds);
                    when(dfList, lang.hitch(this, function () {
                        this._dropFromCatalogList = false;
                    }));
                    return dfList;
                }));
            }));
        },

        _showContentTypeAlert: function (response) {
            // summary:
            //      Show an alert dialog if a content type can't be dropped
            // tags:
            //      protected

            if (this._invalidContentTypeAlertDialog) {
                this._invalidContentTypeAlertDialog.destroy();
            }

            this.own(this._invalidContentTypeAlertDialog = new Alert({
                destroyOnHide: true,
                description: epiString.toHTML(resources.contenttypesnotallowed)
            }));

            this._invalidContentTypeAlertDialog.show();
        },

        _performAction: function(item, newParentItem, actionType){
            var content = item.dndData.data;
            if (content){
                var oldParentItem = this.getParentItem(item.dndData);
                return this.pasteItem(content, oldParentItem, newParentItem, actionType);
            }
        },

        getParentItem: function(dndData){
            if (dndData && dndData.options && dndData.options.oldParentItem) {
                return dndData.options.oldParentItem;
            }
            throw "The item is not supported. The drag source must specify options containing the oldParentItem.";
        },

        _newItemConfirmation: function (hideMoveOption, hideLinkOption) {
            var deferred = new Deferred();

            var pasteItemDialog = new CatalogPasteItemDialog({
                hideMoveOption: hideMoveOption,
                hideLinkOption: hideLinkOption,
                executeDialog: function(actionType) {
                    deferred.resolve(actionType);
                },
                cancelDialog: function() {
                    deferred.cancel();
                }
            });

            var dialog = new Dialog({
                dialogClass: "epi-dialog-confirm",
                defaultActionsVisible: false,
                content: pasteItemDialog,
                title: pasteItemDialog.title,
                destroyOnHide: true
            });

            dialog.show();

            return deferred.promise;
        },

        _selectItemOnPasteComplete: function (item, copy, isDeleted, oldParentItem, newParentItem) {
            // summary:
            //		Select an item after a paste operation has completed. Override this function to keep current context when moving content.
            // item: Item
            //      The target item of the operation
            // copy: boolean
            //      If it was a copy operation or not
            // isDeleted: boolean
            //      If the operation resulted in the item being deleted, i.e. moved to the trash
            // oldParentItem: Item
            //      The curent parent item
            // newParentItem: Item
            //      The target item for the operation
            // tags: protected, override

            if (this._dropFromCatalogList === true) {
                // keep the selected/viewing page, instead of selecting the new parent page in case of dropping item from Catalog list to Catalog tree, to make it consisten with common UX pattern.
            } else {
                // otherwise, invoke base function to select new node.
                this.inherited(arguments);
            }
        },

        _getRelations: function(contentLink) {
            return this.relationStore.query({ referenceId: contentLink });
        },

        _addRelation: function(childItem, newParentItem) {
            return when(this._getRelations(childItem.contentLink), lang.hitch(this, function(relations) {
                var maxSortOrder = 0;
                array.forEach(relations, function(relation) {
                    if (relation.sortOrder > maxSortOrder) {
                        maxSortOrder = relation.sortOrder;
                    }
                });
                return when(this.relationStore.add({
                    source: childItem.contentLink,
                    target: newParentItem.contentLink,
                    type: ModelSupport.relationType.node,
                    sortOrder: maxSortOrder + 100
                }), function (addedItem) {
                    topic.publish("relationChanged", addedItem);
                });
            }));
        },

        _replaceRelation: function(childItem, oldParentItem, newParentItem) {
            return when(this._getRelations(childItem.contentLink), lang.hitch(this, function(relations) {
                array.forEach(relations, function(oldRelation) {
                    if (oldRelation.type === ModelSupport.relationType.node && ContentReference.compareIgnoreVersion(oldRelation.target, oldParentItem.contentLink)) {
                        var newRelation = {
                            source: childItem.contentLink,
                            target: newParentItem.contentLink,
                            type: ModelSupport.relationType.node,
                            sortOrder: oldRelation.sortOrder
                        };
                        return when(this.relationStore.remove(oldRelation.id), lang.hitch(this, function() {
                            return when(this.relationStore.add(newRelation), function(addedItem) {
                                topic.publish("relationChanged", addedItem);
                                });
                        }));
                    }
                }, this);
            }));
        },

        copy: function (source, target) {
            return when(this._isContentTypeAllowed(source, target), lang.hitch(this, function(isContentTypesAllowed){

                if(!isContentTypesAllowed) {
                    this._showContentTypeAlert();
                    return;
                }
                var isLinkSupported = this._isLinkSupported(target.typeIdentifier);
                return when(this._newItemConfirmation(true, !isLinkSupported), lang.hitch(this, function (choice) {
                    var deferreds = array.map(source, function (item) {
                        return when(this.store.get(item.data.parentLink), lang.hitch(this, function (oldParent) {
                            return this.pasteItem(item.data, oldParent, target, choice);
                        }));
                    }, this);
                    return promiseAll(deferreds).then(lang.hitch(this, function (copiedItem) {
                        topic.publish("itemPasted",copiedItem);
                    }));
                }));
            }));
        },

        _isContentTypeAllowed: function(items, target, checkItemFunc) {
            return when(this.contentTypeStore.query({query: "getavailablecontenttypes", parentReference: target.contentLink}), lang.hitch(this, function(contentTypes){
                var availableTypeIds = array.map(contentTypes, function(contentType){
                    return contentType.id;
                });

                if (!checkItemFunc) {
                    checkItemFunc = function(items, availableContentTypeIds) {
                        return array.every(items, function(item) {
                            if (!item.data) {
                                return false;
                            }
                            return availableContentTypeIds.indexOf(item.data.contentTypeID) > -1;
                        });
                    };
                }
                return checkItemFunc(items, availableTypeIds);
            }));
        },

        move: function (source, target) {
            // summary:
            //      Move source item to target
            if (!target.contentLink) {
                target = this.store.get(target);
            }

            return when(this._isContentTypeAllowed(source, target), lang.hitch(this, function(isContentTypesAllowed){
                if (!isContentTypesAllowed){
                    this._showContentTypeAlert();
                    return;
                }
                var deferreds = array.map(source, function (item) {
                    if (item.data) {
                        var oldParent = { contentLink: new ContentReference(item.data.parentLink).createVersionUnspecificReference().toString() };
                        return this.pasteItem(item.data, oldParent, target, "move");
                    }
                }, this);
                return promiseAll(deferreds).then(lang.hitch(this, function (movedItem) {
                    topic.publish("itemPasted", movedItem);
                }));
            }));
        },

        canCut: function (item) {
            // summary:
            //      disable cutting when entry doesn't belong to current category
            var isRelated = false;
            if (item.properties)
            {
                isRelated = item.properties.isRelatedToCurrentCategory;
            }
            return isRelated && this.inherited(arguments);
        },

        onDeleted: function (deletedItems) {

            // summary:
            //		Published a "catalogContentDeleted" topic when all rows are deleted.

            topic.publish("catalogContentDeleted", deletedItems);
        },

        remove: function(items) {
            // summary:
            //      Removes the specified items from the catalog


            // since ecf does not handle multiple async delete requests very well
            // we're using a separate delete controller to batch delete multiple items
            var urlToDeleteController = routes.getActionPath({
                    moduleArea: "EPiServer.Commerce.Shell",
                    controller: "Delete",
                    action: "Delete"
                }),
                contentReferences = array.map(items, function(item) {
                    return item.data.contentLink;
                }),

                params = {
                    url: urlToDeleteController,
                    postData: { contentReferences: contentReferences },
                    handleAs: "json",
                    xsrfProtection: true
                },

                postRequest = this.xhrHandler.xhr("POST", params),
                deleteDeferred = new Deferred();

            when(this.currentContentService.getCurrentContext(), lang.hitch(this, function(currentContext) {
                this.getAncestors(currentContext, lang.hitch(this, function(ancestors){
                    when(postRequest, lang.hitch(this, function() {
                        array.some(items, function(item){
                            if (ContentReference.compareIgnoreVersion(currentContext.id, item.data.contentLink) && item.data.parentLink) {
                                // we're deleting the currently selected item and need to change selection.
                                this.onSelect(item.data.parentLink, true);
                                return true;
                            } else {
                                return array.some(ancestors, function(ancestor){
                                    if (ContentReference.compareIgnoreVersion(ancestor.contentLink, item.data.contentLink) && item.data.parentLink) {
                                        // we're deleting an ancestor to the currently selected item and need to change selection.
                                        this.onSelect(item.data.parentLink, true);
                                        return true;
                                    }
                                }, this);
                            }
                        }, this);

                        //since we're deleting in a separate controller we need to tell the structure store that items are deleted.
                        var promises = array.map(contentReferences, function(contentLink){
                            return this.store.notify(undefined, contentLink);
                        }, this);
                        when(promiseAll(promises), lang.hitch(this, function(){
                            this.onDeleted(items);
                            deleteDeferred.resolve(items);
                        }));
                    }));
                }));
            }));
            return deleteDeferred.promise;
        },

        _isLinkSupported: function(dataType) {
            return this.typeDescriptorManager.isBaseTypeIdentifier(dataType, ModelSupport.contentTypeIdentifier.entryContentBase) ||
                this.typeDescriptorManager.isBaseTypeIdentifier(dataType, ModelSupport.contentTypeIdentifier.nodeContent);
        },

        isSupportedType: function (dataType) {
            var isSupportedType = this.inherited(arguments);
            var inheritFromAnyContainedType = array.some(this.containedTypes, function(containedType){
                return this.typeDescriptorManager.isBaseTypeIdentifier(dataType, containedType);
            }, this);
            return isSupportedType || inheritFromAnyContainedType;
        }
    });
});